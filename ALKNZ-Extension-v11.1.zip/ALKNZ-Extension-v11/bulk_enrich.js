// Sequential enrichment queue for bulk mode.
// Depends on: state, getSettings, buildAuthHeader, showToast (globals from earlier scripts)
// renderQueueStatus is defined in form_bulk.js (loaded before this file).

async function runBulkEnrichmentQueue() {
  const settings = await getSettings();
  if (!settings.backendUrl) {
    showToast('Configure Backend URL in settings first', 'error');
    return;
  }
  const authHeader = buildAuthHeader(settings);
  const authHeaders = authHeader ? { 'Authorization': authHeader } : {};

  for (let i = 0; i < state.bulkEnrichmentQueue.length; i++) {
    const job = state.bulkEnrichmentQueue[i];
    if (job.status !== 'queued') continue;

    // Update UI to searching
    job.status = 'searching';
    updateQueueCard(i);

    try {
      const response = await fetch(`${settings.backendUrl}/api/v1/enrichment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({
          name: job.person_name,
          company: job.firm_name || null,
          additional_urls: job.linkedin_url ? [job.linkedin_url] : []
        })
      }).catch(() => null);

      if (response?.ok) {
        const data = await response.json().catch(() => null);
        job.enrichment = data?.data?.extracted || null;
        job.status = 'done';
      } else {
        // Fallback: try legacy endpoint
        const fallback = await fetch(`${settings.backendUrl}/api/deep-search`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeaders },
          body: JSON.stringify({ name: job.person_name, company: job.firm_name || null, additional_urls: [] })
        }).catch(() => null);
        if (fallback?.ok) {
          const data = await fallback.json().catch(() => null);
          job.enrichment = data?.data?.extracted || null;
          job.status = 'done';
        } else {
          job.status = 'error';
        }
      }
    } catch {
      job.status = 'error';
    }

    updateQueueCard(i);

    // 1-second delay between calls to avoid rate limiting
    if (i < state.bulkEnrichmentQueue.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}

function updateQueueCard(i) {
  const statusEl  = document.getElementById(`bulk-queue-status-${i}`);
  const actionsEl = document.getElementById(`bulk-queue-actions-${i}`);
  const job = state.bulkEnrichmentQueue[i];
  if (!job) return;
  if (statusEl)  statusEl.innerHTML = renderQueueStatus(job);
  if (statusEl)  statusEl.className = `bulk-queue-status bulk-queue-status--${job.status}`;
  if (actionsEl) actionsEl.style.display = job.status === 'done' ? 'flex' : 'none';
}
