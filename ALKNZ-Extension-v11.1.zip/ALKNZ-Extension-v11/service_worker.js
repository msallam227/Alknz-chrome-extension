chrome.runtime.onInstalled.addListener(() => {
  console.log('ALKNZ Investor Capture extension installed');
});

// Called every time the service worker starts (not just on install),
// so the side panel behaviour is always correctly set.
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
  .catch((error) => console.error('Failed to set side panel behavior:', error));

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'GET_PAGE_INFO') {
    sendResponse({ received: true });
  }
  return true;
});
